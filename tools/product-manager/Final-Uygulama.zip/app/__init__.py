# Temiz Is Ürün Yöneticisi
